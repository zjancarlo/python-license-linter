# python-license-linter
Gets license information of packages listed in provided requirements.txt and checks them against a list of blacklisted licenses.
